<?php
class testClass
{
    public $test;

    public function __destruct()
    {
        return $this->test;
    }
}
?>