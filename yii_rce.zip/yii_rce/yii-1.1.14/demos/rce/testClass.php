<?php
class testClass
{
    public static function test()
    {
        return 1;
    }
}
?>